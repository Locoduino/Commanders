/*************************************************************
project: <Commanders>
author: <Thierry PARIS>
description: <Basic button.>
*************************************************************/

#include "ButtonsCommanderButton.hpp"

COMMANDERS_EVENT_TYPE ButtonsCommanderButton::eventType;
int ButtonsCommanderButton::eventData;

