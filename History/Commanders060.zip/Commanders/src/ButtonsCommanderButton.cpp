/*************************************************************
project: <Universal Accessory Decoder>
author: <Thierry PARIS>
description: <Basic button.>
*************************************************************/

#include "ButtonsCommanderButton.hpp"

