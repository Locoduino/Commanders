#include "Wire.hpp"

WireClass WireClass::WireInstance;